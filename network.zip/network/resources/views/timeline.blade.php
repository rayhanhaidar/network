<x-app-layout>
    @slot('header')
        Timeline
    @endslot
    Timeline
</x-app-layout>